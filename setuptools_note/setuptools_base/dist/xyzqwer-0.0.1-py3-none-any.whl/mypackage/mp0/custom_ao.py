def c_add(a, b):
    return a + b


def c_sub(a, b):
    return a - b
