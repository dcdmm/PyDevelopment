def ph():
    print("hello python")
    print("hello c++")
    print("hello rust")