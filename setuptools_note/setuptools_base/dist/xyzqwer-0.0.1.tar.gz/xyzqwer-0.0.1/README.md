# xyzqwer

setuptools test project

## Installation

```bash
pip install xyzqwer
```

## Description

This is a test project for demonstrating setuptools configuration.
